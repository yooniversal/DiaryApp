package com.example.newProject.db

//Output
data class Login(
        val code: String,
        val msg : String
)